class Point {
    double x, y;
    int r, g, b;

    public Point(double x, double y, int r, int g, int b) {
        this.x = x;
        this.y = y;
        this.r = r;
        this.g = g;
        this.b = b;
    }
}